package com.fepoc.ms.server.edgeregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FepdirectMsRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
