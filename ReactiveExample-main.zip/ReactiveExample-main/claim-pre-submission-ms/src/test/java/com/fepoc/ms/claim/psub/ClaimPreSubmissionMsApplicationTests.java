package com.fepoc.ms.claim.psub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimPreSubmissionMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
