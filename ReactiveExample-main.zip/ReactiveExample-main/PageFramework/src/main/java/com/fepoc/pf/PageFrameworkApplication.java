package com.fepoc.pf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PageFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(PageFrameworkApplication.class, args);
	}

}
