package com.fepoc.ms.server.edge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FepdirectMsEdgeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
