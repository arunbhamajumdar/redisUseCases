package com.fepoc.claim.domain;

public class DentalClaim extends BaseClaim{

	
}
