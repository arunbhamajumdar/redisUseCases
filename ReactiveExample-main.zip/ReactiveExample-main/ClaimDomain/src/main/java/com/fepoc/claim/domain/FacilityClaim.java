package com.fepoc.claim.domain;

public class FacilityClaim extends BaseClaim{

}
