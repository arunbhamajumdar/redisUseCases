package com.fepoc.claim.domain;

public class MedicalClaim extends BaseClaim{

}
