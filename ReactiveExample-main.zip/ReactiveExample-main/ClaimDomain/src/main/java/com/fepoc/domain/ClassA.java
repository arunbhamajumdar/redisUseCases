package com.fepoc.domain;

public class ClassA implements Cloneable{
	private ClassB classB;

	public ClassB getClassB() {
		return classB;
	}

	public void setClassB(ClassB classB) {
		this.classB = classB;
	}
	
	
}
