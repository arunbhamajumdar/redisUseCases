package com.fepoc.domain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimDomainApplicationTests {

	@Test
	void contextLoads() {
	}

}
