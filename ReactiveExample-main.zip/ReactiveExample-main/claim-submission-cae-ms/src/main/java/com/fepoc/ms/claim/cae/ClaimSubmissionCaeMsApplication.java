package com.fepoc.ms.claim.cae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimSubmissionCaeMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimSubmissionCaeMsApplication.class, args);
	}

}
