package com.fepoc.ms.claim.cae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimSubmissionCaeMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
