package com.fepoc.ms.claim.ccae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimSubmissionCcaeMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
