package com.fepoc.cf.excp;

public class DuplicateClaimException extends Exception{
	private static final long serialVersionUID = 1L;

}
