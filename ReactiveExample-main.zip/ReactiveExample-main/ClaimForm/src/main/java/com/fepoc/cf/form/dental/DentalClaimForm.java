package com.fepoc.cf.form.dental;

import com.fepoc.cf.form.BaseClaimForm;
import com.fepoc.claim.domain.DentalClaim;

public class DentalClaimForm extends BaseClaimForm{

	public DentalClaimForm(DentalClaim dentalClaim) {
		super(dentalClaim);
	}

}
