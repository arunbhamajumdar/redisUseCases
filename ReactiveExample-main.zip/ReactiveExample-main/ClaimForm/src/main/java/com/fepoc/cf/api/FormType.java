package com.fepoc.cf.api;

public enum FormType {
	Dental, Medical, Pharmacy;
}
