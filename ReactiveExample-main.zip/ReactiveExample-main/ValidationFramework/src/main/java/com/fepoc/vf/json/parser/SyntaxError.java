package com.fepoc.vf.json.parser;

public class SyntaxError extends Exception {

	private static final long serialVersionUID = 1L;

}
