package com.fepoc.vf.json.schema;

public class JsonThenProperty<E extends JsonBaseType> extends JsonProperty<E> {

	public JsonThenProperty(E propertyReference) {
		super(propertyReference);
	}


}
