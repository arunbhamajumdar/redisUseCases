package com.fepoc.vf.json.schema;

public class JsonObjectSchemaDependency {

}
