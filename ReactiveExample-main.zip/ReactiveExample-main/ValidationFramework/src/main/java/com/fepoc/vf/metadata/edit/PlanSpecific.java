package com.fepoc.vf.metadata.edit;

public class PlanSpecific extends BaseEditFunction{

}
