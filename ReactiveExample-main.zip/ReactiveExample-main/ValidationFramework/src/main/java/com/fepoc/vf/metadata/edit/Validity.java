package com.fepoc.vf.metadata.edit;

public class Validity extends BaseEditFunction{
	private EditFunction editFunction;
	private EditCategory editCategory;
	private EditComponent editComponent;
}
