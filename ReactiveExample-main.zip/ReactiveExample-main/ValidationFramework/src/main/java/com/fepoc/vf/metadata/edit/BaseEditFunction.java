package com.fepoc.vf.metadata.edit;

public abstract class BaseEditFunction {
	protected String code;
	protected String title;
	protected String description;
	protected String notes;
	protected String resolution;
	protected String resolutionFlag;

}
