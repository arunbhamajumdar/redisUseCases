package com.fepoc.vf.json.parser;

public class JsonArrayBlock extends JsonBlock{

}
