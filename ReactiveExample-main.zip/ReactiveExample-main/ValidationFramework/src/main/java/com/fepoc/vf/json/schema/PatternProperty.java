package com.fepoc.vf.json.schema;

public class PatternProperty {
	private String namePattern;
	private JsonProperty property;
	public String getNamePattern() {
		return namePattern;
	}
	public void setNamePattern(String namePattern) {
		this.namePattern = namePattern;
	}
	public JsonProperty getProperty() {
		return property;
	}
	public void setProperty(JsonProperty property) {
		this.property = property;
	}
	
	
}
