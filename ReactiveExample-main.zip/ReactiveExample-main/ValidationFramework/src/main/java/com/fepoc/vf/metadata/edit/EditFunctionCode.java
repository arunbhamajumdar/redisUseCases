package com.fepoc.vf.metadata.edit;

public class EditFunctionCode {
	private String functioCode;
	private String functionDescription;
	private EditFunction editFunction;
	private EditCategory editCategory;
	
	
}
