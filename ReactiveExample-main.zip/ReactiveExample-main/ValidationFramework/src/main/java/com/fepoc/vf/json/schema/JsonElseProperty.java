package com.fepoc.vf.json.schema;

public class JsonElseProperty<E extends JsonBaseType> extends JsonProperty<E> {

	public JsonElseProperty(E propertyReference) {
		super(propertyReference);
	}

}
