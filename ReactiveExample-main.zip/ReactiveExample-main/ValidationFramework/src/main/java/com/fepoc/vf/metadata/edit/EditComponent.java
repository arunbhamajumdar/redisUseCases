package com.fepoc.vf.metadata.edit;

public class EditComponent {

}
