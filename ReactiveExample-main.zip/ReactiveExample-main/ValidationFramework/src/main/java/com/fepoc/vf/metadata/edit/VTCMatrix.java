package com.fepoc.vf.metadata.edit;

import java.util.List;

public class VTCMatrix {
	private String fieldName;
	private EditFunction validityCode;
	private List<EditFunction> compatibiltyCodes;
}
