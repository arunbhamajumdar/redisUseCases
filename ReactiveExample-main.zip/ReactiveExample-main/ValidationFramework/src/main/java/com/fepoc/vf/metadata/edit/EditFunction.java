package com.fepoc.vf.metadata.edit;

public enum EditFunction {
	Compatibility, Validation, PlanSpecific
}
