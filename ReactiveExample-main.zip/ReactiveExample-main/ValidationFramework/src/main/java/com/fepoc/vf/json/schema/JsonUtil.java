package com.fepoc.vf.json.schema;

public class JsonUtil {
	public static String quote(String str) {
		return "\"".concat(str).concat("\"");
	}
}
