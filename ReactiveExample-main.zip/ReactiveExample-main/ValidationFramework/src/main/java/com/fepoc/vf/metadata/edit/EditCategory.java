package com.fepoc.vf.metadata.edit;

public enum EditCategory {
	AllClaims,
	ProfessionalOnly,
	ProfessionalAndFacilityOutpatient,
	MultiChargeLines,
	FacilityAll,
	FacilityOutpatient,
	FacilityInpatient,
	FacilityPharmacy
}
