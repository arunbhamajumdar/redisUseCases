package com.fepoc.vf.json.schema;

public class JsonIfProperty<E extends JsonBaseType> extends JsonProperty<E> {

	public JsonIfProperty(E propertyReference) {
		super(propertyReference);
	}

}
