package com.fepoc.vf.jsr303.visitor;
public interface VisitorI {
	public int visit(VisitableI visitale);
}