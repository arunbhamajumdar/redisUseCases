package com.fepoc.vf.jsr303;

public interface NoValidation {

}
