package com.fepoc.vf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
