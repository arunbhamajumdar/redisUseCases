package com.fepoc.tm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FepdirectTransactionManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
