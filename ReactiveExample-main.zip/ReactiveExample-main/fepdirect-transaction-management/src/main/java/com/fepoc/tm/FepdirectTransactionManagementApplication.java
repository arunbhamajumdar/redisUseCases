package com.fepoc.tm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FepdirectTransactionManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FepdirectTransactionManagementApplication.class, args);
	}

}
