package com.induscf.rs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedirectServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedirectServerApplication.class, args);
	}

}
