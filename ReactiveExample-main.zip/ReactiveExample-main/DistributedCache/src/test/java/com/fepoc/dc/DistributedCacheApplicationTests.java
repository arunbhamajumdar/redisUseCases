package com.fepoc.dc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
