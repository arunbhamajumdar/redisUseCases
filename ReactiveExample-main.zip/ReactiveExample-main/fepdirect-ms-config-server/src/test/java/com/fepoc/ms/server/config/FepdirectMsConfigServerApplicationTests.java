package com.fepoc.ms.server.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FepdirectMsConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
