package com.fepoc.sec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
