package com.fepoc.ms.lb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FepdirectMsLbServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
